document.getElementById('home-link').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('menu');
});

document.getElementById('home-link3').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('materias');
});

document.getElementById('home-link2').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('infuser');
});

document.getElementById('home-link4').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('eventos');
});
document.getElementById('home-link5').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('noticias');
});
document.getElementById('home-link6').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('calculadora');
});
document.getElementById('home-link7').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('redes');
});
document.getElementById('home-link8').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('recursos');
});
document.getElementById('home-link9').addEventListener('click', function(event) {
    event.preventDefault();
    toggleDisplay('miembros');
});


function toggleDisplay(id) {
    var sections = ['menu', 'materias', 'infuser','eventos','noticias','calculadora','redes','recursos','miembros','videos'];
    sections.forEach(function(section) {
        var element = document.getElementById(section);
        if (section === id) {
            element.style.display = (element.style.display === 'block') ? 'none' : 'block';
        } else {
            element.style.display = 'none';
        }
    });
}