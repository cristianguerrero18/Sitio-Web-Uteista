function calculateFinalGrade() {
    // Obtiene los valores de las notas de los cortes y los porcentajes
    const corte1 = parseFloat(document.getElementById('corte1').value);
    const corte2 = parseFloat(document.getElementById('corte2').value);
    const corte3 = parseFloat(document.getElementById('corte3').value);
    const porcentajeCorte1 = parseFloat(document.getElementById('porcentajeCorte1').value) / 100;
    const porcentajeCorte2 = parseFloat(document.getElementById('porcentajeCorte2').value) / 100;
    const porcentajeCorte3 = parseFloat(document.getElementById('porcentajeCorte3').value) / 100;

    // Verifica que los valores estén en el rango correcto
    if (corte1 < 0 || corte1 > 5 || corte2 < 0 || corte2 > 5 || corte3 < 0 || corte3 > 5 || porcentajeCorte1 < 0 || porcentajeCorte1 > 1 || porcentajeCorte2 < 0 || porcentajeCorte2 > 1 || porcentajeCorte3 < 0 || porcentajeCorte3 > 1) {
        alert('Las notas deben estar entre 0 y 5.0 y los porcentajes entre 0 y 100');
        return;
    }

    // Calcula la nota final ponderada
    const notaFinal = (corte1 * porcentajeCorte1 + corte2 * porcentajeCorte2 + corte3 * porcentajeCorte3).toFixed(2);

    // Muestra la nota final al usuario
    document.getElementById('finalGrade').innerHTML = `Tu nota final es: ${notaFinal}`;
}

function resetForm() {
    document.getElementById('corte1').value = '';
    document.getElementById('corte2').value = '';
    document.getElementById('corte3').value = '';
    document.getElementById('porcentajeCorte1').value = '';
    document.getElementById('porcentajeCorte2').value = '';
    document.getElementById('porcentajeCorte3').value = '';
    document.getElementById('finalGrade').innerText = '';
}
